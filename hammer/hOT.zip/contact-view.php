<!DOCTYPE html>
<html dir="ltr">

<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<head>
    <style>
        .ac_footer {
            position: relative;
            text-align: center;
            overflow: hidden;
            padding: 50px 0;
            color: #A12000;
        }

        .ac_footer a {
            color: #A12000;
        }

        .ac_footer p {
            text-align: center;
        }

        img[height="1"],
        img[width="1"] {
            display: none !important;
        }
    </style>


    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, minimal-ui" name="viewport" />
    <meta content="IE=edge" http-equiv="X-UA-Compatible" />
    <title> Hammer of Thor - दुनिया का नं. 1 उत्पादक लिंग लंबा करने के लिए </title>
    <link href="style.css" media="all" rel="stylesheet" type="text/css" />
</head>

<body class="page">
    <!--retarget-->

    <!--retarget-->

    <div class="page__wrapper js-wrapper">
        <div class="header">
            <div class="container">
                <div class="header__inner">
                    <div class="header__logo">
                        <div class="logo"> Hammer of Thor </div>
                    </div>
                    <div class="header__subtitle"> दुनिया का नं. 1 उत्पादक
                        <span> लिंग </span> लंबा करने के लिए
                    </div>
                    <div class="header__title">
                        <div class="header__title-big"> सबसे बड़ा,</div>
                        <span> पहले </span> से कहीं बड़ा
                    </div>
                    <div class="package__sale12"> free
                        <div class="package__text"> shipping </div>
                    </div>
                    <div class="header__right">
                        <div class="header__timer">
                            <div class="timer">
                                <div class="timer__title"> ऑफर ख़त्म होने में शेष समय </div>
                                <div class="timer__items js-timer"></div>
                            </div>
                        </div>
                        <div class="header__package">
                            <div class="package">
                                <div class="package__sale-text">
                                    <div class="sale"> अभी ऑर्डर करें
                                        <span> और पाएँ </span>
                                    </div>
                                </div>
                                <div class="package__image-wrapper">
                                    <div class="package__sale"> 70%
                                        <div class="package__text"> डिस्काउंट </div>
                                    </div>
                                    <div class="package__image"></div>
                                    <!-- <div class="package__sale" style="  top: -35px; left:-35px; font-size: 0.9em;">
                                        <div class="package__text" style="font-size: 26px;
    margin-top: 1px;"> लिंग मसाज Oil
                                        </div>
                                        <img src="img/sticker.png" width="50px" alt="">
                                        <div class="package__text" style="font-size: 1.6em;"> फ्री
                                        </div>
                                    </div> -->
                                    <!-- <img class="package__sale" style=" width: 200px;  top: -35px; left:-55px; background: no-repeat; " src="img/sticker.png"  alt=""> -->
                                </div>
                            </div>
                        </div>
                        <div class="header__price">
                            <div class="price">
                                <div class="price__inner">
                                    <div class="price__items">
                                        <div class="price__items-old">
                                        </div>
                                        <div class="price__items-new"> 20 Capsules Only Rs.649
                                        </div>
                                    </div>
                                    <div class="price__button">
                                        <div class="button js-scroll-to"> <a style="text-decoration:none; color:#fff;" href="javascript: scrollToForm();"> अभी ऑर्डर करें </a></div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--div class="price__items-new" ><a style="color:red;" href="tel:+91-8929013389">Call Now : 8929013389</a>
</div-->
                    </div>
                    <div class="header__advantages">
                        <div class="header-advantages">
                            <div class="header-advantages__item">
                                <div class="header-advantages__item-icon-wrapper">
                                    <div class="header-advantages__item-icon header-advantages__item-icon_increase">
                                    </div>
                                </div>
                                <div class="header-advantages__item-title"> लिंग लंबा करें

                                </div>
                            </div>
                            <div class="header-advantages__item">
                                <div class="header-advantages__item-icon-wrapper">
                                    <div class="header-advantages__item-icon header-advantages__item-icon_clock"></div>
                                </div>
                                <div class="header-advantages__item-title">
                                    <span> लंबा चलने वाला </span> संभोग
                                </div>
                            </div>
                            <div class="header-advantages__item">
                                <div class="header-advantages__item-icon-wrapper">
                                    <div class="header-advantages__item-icon header-advantages__item-icon_acute"></div>
                                </div>
                                <div class="header-advantages__item-title">
                                    <span> बढ़ाएँ </span> संवेदनाओं को
                                </div>
                            </div>
                            <div class="header-advantages__item">
                                <div class="header-advantages__item-icon-wrapper">
                                    <div class="header-advantages__item-icon header-advantages__item-icon_volume"></div>
                                </div>
                                <div class="header-advantages__item-title"> सेक्सी साइज़ </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="page__content">
            <div class="s-increase">
                <div class="container">
                    <div class="s-increase__title">
                        <div class="s-increase__title-inner">
                            <div class="s-increase__title-top"> असली </div>
                            <div class="s-increase__title-bottom">
                                <span> बढ़त, लिंग के साइज़ में </span> 40%
                                <span> तक बढ़त </span>
                            </div>
                        </div>
                    </div>

                    <div class="s-increase__compare">
                        <div class="compare">
                            <div class="compare__items">
                                <div class="compare__item">
                                    <div class="compare-item compare-item_before">
                                        <div class="compare-item__information-wrapper compare-item__information-wrapper_before">
                                            <div class="compare-item__information compare-item__information_before">
                                                इस्तेमाल के बाद लंबाई-मोटाई दोनों बढ़ जाते हैं।
                                                <span> Hammer of Thor </span> से न सिर्फ
                                                <span>साइज़</span> बल्कि
                                                <span>लंबाई भी बढ़ जाती है।</span>
                                            </div>
                                        </div>
                                        <div class="compare-item__time-wrapper compare-item__time-wrapper_before">
                                            <div class="compare-item__time compare-item__time_before">
                                                <div class="compare-item__time-title"> खड़े होने की अधिकतम अवधि: </div>
                                                <div class="compare-item__time-value"> 10-15 मिनट

                                                </div>
                                            </div>
                                        </div>
                                        <div class="compare-item__label compare-item__label_before"> पहले </div>
                                        <div class="compare-item__length compare-item__length_before"> 14 सेमी </div>
                                        <div class="compare-item__width compare-item__width_before"> 3 सेमी </div>
                                    </div>
                                </div>
                                <div class="compare__item">
                                    <div class="compare-item compare-item_after">
                                        <div class="compare-item__information-wrapper compare-item__information-wrapper_after">
                                            <div class="compare-item__information compare-item__information_after"> लिंग
                                                के उत्तक
                                                <span>सह पाते हैं</span> ज़्यादा दबाव, जिससे बढ़ जाती है संभोग की अवधि
                                                <span>2-3 गुना</span>
                                            </div>
                                        </div>
                                        <div class="compare-item__time-wrapper compare-item__time-wrapper_after">
                                            <div class="compare-item__time compare-item__time_after">
                                                <div class="compare-item__time-title"> खड़े होने की अधिकतम अवधि: </div>
                                                <div class="compare-item__time-value"> 40-75 मिनट
                                                </div>
                                            </div>
                                        </div>
                                        <div class="compare-item__label compare-item__label_after"> बाद में </div>
                                        <div class="compare-item__length compare-item__length_after"> 18 सेमी </div>
                                        <div class="compare-item__width compare-item__width_after"> 5.5 सेमी </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="s-experts">
                <div class="container">
                    <div class="s-experts__title-wrapper">
                        <div class="s-experts__title">
                            <!--div class="s-experts__title-top">  विशेषज्ञ की राय </div>
<div class="s-experts__title-bottom">  इसके बारे में 
              <span>   अभी   </span></div-->
                            <!--div class="price__items-new" ><a style="color:red;" href="tel:+91-8929013389">Call Now : 8929013389</a>
</div-->
                        </div>
                    </div>
                    <div class="s-experts__items">
                        <div class="experts">
                            <div class="experts__item">
                                <div class="experts__item-image-wrapper">
                                    <img alt="" class="experts__item-image" src="img/expert1.png" />
                                    <div class="experts__item-title">
                                        <div class="experts__item-name"> रवि पुरंदरे </div>
                                        <div class="experts__item-post"> सेक्स-रोग विशेषज्ञ </div>
                                    </div>
                                </div>
                                <div class="experts__item-text">
                                    <div class="experts__item-text-shadow"></div>
                                    <p> आधिकारिक आँकड़ों की जानकारी बहुत कम लोगों को ही होती है क्योंकि लिंग का ऑपरेशन
                                        काफी संवेदनशील मुद्दा होता है और लोग इसके बारे में ज़्यादा बात-चीत पसंद नहीं
                                        करते। भारत में हर साल 10,000 लोग अपने लिंग की लंबाई और मोटाई को ऑपरेशन के जरिए
                                        बढ़वाते हैं। हम हमेशा से कहते आए हैं कि इससे स्वास्थ्य के लिए खतरा उत्पन्न हो
                                        जाता है क्योंकि नर्व फाइबर (स्नायु तंत्र की नसें) लिंग की कैविटीज़ में गहरे अंदर
                                        तक गए होते हैं। यदि इन कैविटीज़ में कोई नुक्सान हो जाए तो कई जोखिम उत्पन्न हो
                                        जाते हैं, जैसे संवेदना चला जाना, खड़े होने में दर्द होना और नामर्दी। </p>
                                    <p> ऑपरेशन की तुलना में <span>Hammer of Thor</span> के कोई गंभीर साइड-इफ़ेक्ट नहीं
                                        हैं। यह शरीर को प्राकृतिक रूप से लिंग में वसा-उत्तकों को इखट्ठा करने के लिए
                                        प्रेरित करती है।
                                    </p>
                                </div>
                            </div>
                            <div class="experts__item">
                                <div class="experts__item-image-wrapper">
                                    <img alt="" class="experts__item-image" src="img/expert2.png" />
                                    <div class="experts__item-title">
                                        <div class="experts__item-name"> मनोज त्रिवेदी </div>
                                        <div class="experts__item-post"> सेक्स-रोग विशेषज्ञ </div>
                                    </div>
                                </div>
                                <div class="experts__item-text">
                                    <div class="experts__item-text-shadow"></div>
                                    <p> योनि का सबसे संवेदनशील हिस्सा 2-3 सेमी की गहराई में स्थित होता है। आम तौर पर सब
                                        सोचते हैं कि औरत के आनंद के लिए लिंग का लंबा होना ज़्यादा महत्वपूर्ण होता है,
                                        लेकिन ऐसा नहीं है। आदमी के लिंग की मोटाई (साइज़) औरत के आनंद के लिए ज़्यादा जरूरी
                                        होता है। आपका लिंग जितना मोटा और कड़ा होगा, आपकी पत्नी उतनी ही संतुष्ट हो पाएगी।
                                    </p>
                                    <p> यही नहीं, मोटा लिंग संभोग के दौरान औरत की क्लिटोरिस (भागांकुर) को उत्तेजित करके
                                        एहसास कई गुना बढ़ा देता है जिससे ओरगाज़्म होने का असर कई गुना बढ़ जाता है। </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="s-reviews">
                <div class="container">
                    <div class="s-reviews__title-wrapper">
                        <div class="s-reviews__title">
                            <div class="s-reviews__title-top"> लोग पहले ही </div>
                            <div class="s-reviews__title-bottom">
                                <span> Hammer of Thor </span> ट्राय कर के देख चुके हैं!
                            </div>
                        </div>
                    </div>
                    <div class="s-reviews__items">
                        <div class="reviews">
                            <div class="reviews__items">
                                <div class="reviews__item">
                                    <div class="reviews__item-image-wrapper">
                                        <img alt="" class="reviews__item-image" src="img/reviewer-anonim.png" />
                                    </div>
                                    <div class="reviews__item-text-wrapper">
                                        <div class="reviews__item-title-wrapper">
                                            <div class="reviews__item-name-wrapper">
                                                <div class="reviews__item-name"> ज़हीन </div>
                                                <div class="reviews__item-age"> 26 साल </div>
                                            </div>
                                            <div class="reviews__item-title">
                                                <span> मैं अपनी बीवी को कभी पूरी संतुष्टि नहीं दे पाया </span>
                                            </div>
                                        </div>
                                        <div class="reviews__item-text"> और वो भी इसको लेकर हमेशा नाराज़ रहती थी: उसने
                                            मुझसे कई बार इसके लिए कुछ करने को कहा क्योंकि मेरा लिंग बहुत छोटा था! मैं
                                            बहुत दुखी रहता था और मैंने कई तरह के इलाजों के बारे में सोचा। आखिर में मुझे
                                            पसंद आई
                                            <span>Hammer of Thor</span>.अब मुझे इसे लगाते 3 हफ्ते हो चुके हैं,
                                            <span>और मेरा लिंग काफी बड़ा हो गया है</span> और मेरी बीवी को भी महसूस होने
                                            लगा है। वो अब मुझसे कई बार सेक्स करने को कहती है।
                                        </div>
                                    </div>
                                </div>

                                <div class="reviews__item">
                                    <div class="reviews__item-image-wrapper">
                                        <img alt="" class="reviews__item-image" src="img/reviewer-anonim.png" />
                                    </div>
                                    <div class="reviews__item-text-wrapper">
                                        <div class="reviews__item-title-wrapper">
                                            <div class="reviews__item-name-wrapper">
                                                <div class="reviews__item-name"> जितेंद्र </div>
                                                <div class="reviews__item-age"> 36 साल </div>
                                            </div>
                                            <div class="reviews__item-title">
                                                <span> Hammer of Thor के बिना तो सेक्स में मजा ही नहीं आता था, सेक्स
                                                    लाइफ बोरिंग हो गई थी </span>
                                            </div>
                                        </div>
                                        <div class="reviews__item-text"> हमारी शादी को 8 साल हो चुके हैं और हम लोग
                                            एक जैसे सेक्स करके बोर हो गए थे। डेलीवरी होने के बाद वैसे भी औरतों को
                                            लिंग थोड़ा लंबा चाहिए होता है। फिर मैंने ट्राय की
                                            <span>Hammer of Thor</span> ताकि सेक्स के दौरान और मजा और उन्माद बढ़ जाए।
                                            मेरी बीवी का कहना है,
                                            <span>कि उसने आखिरकार अब जाकर मेरे लिंग को महसूस किया है।</span> अब हम
                                            हफ्ते में कई बार सेक्स करते हैं।
                                            <span>मैंने एक और पैकेज का ऑर्डर कर दिया है।</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="reviews__item">
                                    <div class="reviews__item-image-wrapper">
                                        <img alt="" class="reviews__item-image" src="img/reviewer2.png" />
                                    </div>
                                    <div class="reviews__item-text-wrapper">
                                        <div class="reviews__item-title-wrapper">
                                            <div class="reviews__item-name-wrapper">
                                                <div class="reviews__item-name"> हार्दिक </div>
                                                <div class="reviews__item-age"> 27 साल </div-->
                                                </div>
                                                <div class="reviews__item-title">
                                                    <span> सबसे बेहतरीन प्रोडक्ट जो असर करता है
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="reviews__item-text"> मेरी शादी बीस साल की उम्र में हो गई थी
                                                और मेरी बीवी तब 25 की थी। मेरी पत्नी की ये दूसरी शादी थी इसलिए मुझे
                                                हमेशा डर लगा रहता था कि मैं उसे संतुष्ट नहीं कर पाऊँगा। मैंने
                                                इंटरनेट पर बहुत सर्च की कि अनुभवी आदमी इस परिस्थिती में क्या करते
                                                हैं, और मुझे यही समझ में आया कि
                                                <span>Hammer of Thor</span> लेना ही समझदारी होगी। इसलिए मैंने अपनी
                                                पत्नी से पूछा और उसने खुशी से हाँ कह दिया!
                                            </diV>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer">
                <div class="container">
                    <div class="footer__inner">
                        <div class="footer__title">
                            <div class="footer__title-top">
                                <div class="footer__title-top-left"> अपनी पार्टनर को दीजिए </div>
                                <div class="footer__title-top-right"> चरम सुख और उत्तेजना </div>
                            </div>
                            <div class="footer__title-bottom"> जिसकी वो हकदार है </div>
                        </div>
                        <div class="footer__content">
                            <div class="footer__left">
                                <div class="footer__timer">
                                    <div class="timer">
                                        <div class="timer__title"> ऑफर खत्म होने में शेष समय </div>
                                        <div class="timer__items js-timer">
                                        </div>
                                    </div>
                                </div>
                                <div class="footer__package">
                                    <div class="package">
                                        <div class="package__sale-text">
                                            <div class="sale"> अभी ऑर्डर करें
                                                <span> और पाएँ </span>
                                            </div>
                                        </div>
                                        <div class="package__image-wrapper">
                                            <div class="package__sale"> 70%
                                                <div class="package__text"> डिस्काउंट </div>
                                            </div>
                                            <div class="package__image"></div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="footer__form " id="order">

                                <form name="frmContact" id="frmContact" method="post" action="" enctype="multipart/form-data">
                                    <div class="form__rows">
                                        <div class="form__title"> ऑर्डर करें </div>

                                        <div class="form__row">
                                            <input class="input" name="userName" id="userName" placeholder="नाम" type="text" value="" />
                                        </div>
                                        <div class="form__row">
                                            <input class="input only only_number" name="subject" id="subject" placeholder="फ़ोन " type="text" value="" />
                                        </div>
                                        <!--div class="form__row">
<input class="input only only_number" name="content" id="content" placeholder="पिनकोड" type="text" value=""/>
</div>
<div class="form__row">
<input class="input only only_number" name="userEmail" id="userEmail" placeholder="पूरा पता" type="text" value=""/>
</div-->
                                        <div class="form__row">
                                            <select class="form-control" class="input only only_number" name="baddress" id="baddress" placeholder="price" type="text" value="">
                                                <option value="20 Capsules Only Rs.649">20 Capsules Only Rs.649</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form__price">
                                        <div class="price">
                                            <div class="price__inner">
                                                <div class="price__items">
                                                    <div class="price__items-old">
                                                    </div>
                                                    <div class="price__items-new"> 20 Capsules Only Rs.649
                                                    </div>
                                                </div>

                                                <div class="price__button">
                                                    <input class="button  button__text" type="submit" name="send" class="buttonIndex" value=" अभी ऑर्डर करें " />

                                                    <div id="statusMessage">
                                                    </div>
                                                </div>
                                                <?php
                                                if (!empty($message)) {
                                                ?>
                                                    <p class='<?php echo $type; ?>Message'>
                                                        <?php
                                                        echo '<script language="javascript">';
                                                        echo 'window.location = "db.php";';
                                                        echo '</script>';
                                                        ?>
                                                    </p>
                                                <?php
                                                }
                                                ?>

                                            </div>
                                        </div>
                                    </div>
                                    <input name="time_zone" type="hidden" value="3" />
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <template id="js-timer-html">
                <div class="timer__item"> {h10}{h1}</div>
                <div class="timer__item"> {m10}{m1}</div>
                <div class="timer__item"> {s10}{s1}</div>
            </template>


            <div class="ac_footer"><span>&copy; 2020 Copyright. All rights reserved.</span><br>
                <a href="" target="_blank">Privacy policy</a> | <a href="">Report</a>
                <p>The results may vary depending on your individual features </p>

            </div>
            <!-- <a href="https://api.whatsapp.com/send?phone=+918929013389&text=Hello%21%20I%20am%20Dr.%20Rohit,%20How%20May%20I%20Help%20you?"
                    class="float" target="_blank">
                    <i class="fa fa-whatsapp my-float"></i>
                </a> -->

            <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
            <script type="text/javascript">
                function scrollToForm() {
                    document.querySelector('#frmContact').scrollIntoView({
                        behavior: 'smooth'
                    })
                }

                // function validateContactForm() {
                //     var valid = true;

                //     $(".info").html("");
                //     $(".input-field").css('border', '#e0dfdf 1px solid');
                //     var userName = $("#userName").val();
                //     var userEmail = $("#userEmail").val();
                //     var subject = $("#subject").val();
                //     var baddress = $("#baddress").val();
                //     var content = $("#content").val();

                //     if (userName == "") {
                //         $("#userName-info").html("Required.");
                //         $("#userName").css('border', '#e66262 1px solid');
                //         valid = false;
                //     }

                //     if (subject == "") {
                //         $("#subject-info").html("Required.");
                //         $("#subject").css('border', '#e66262 1px solid');
                //         valid = false;
                //     }

                //     if (baddress == "") {
                //         $("#baddress-info").html("Required.");
                //         $("#baddress").css('border', '#e66262 1px solid');
                //         valid = false;
                //     }

                //     return valid;
                // }
            </script>
</body>


</html>