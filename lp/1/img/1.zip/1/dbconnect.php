<?php session_start();

global $db;
$GLOBALS['db'] = mysqli_connect("localhost", "root1_titangoldcoin1", "tgold@23456", "root1_titangold.co.in1");

?>

