-- MySQL dump 10.13  Distrib 5.6.41-84.1, for Linux (x86_64)
--
-- Host: localhost    Database: buytiv3z_megalargecoin
-- ------------------------------------------------------
-- Server version	5.6.41-84.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(2855) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(2855) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` (`id`, `username`, `password`) VALUES (1,'plus','f8b0766a115224336cde4013b09f92cf');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registration`
--

DROP TABLE IF EXISTS `registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registration` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(2855) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` varchar(2855) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_email` varchar(2855) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(2855) COLLATE utf8_unicode_ci NOT NULL,
  `baddress` varchar(2544) COLLATE utf8_unicode_ci DEFAULT NULL,
  `modified_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registration`
--

LOCK TABLES `registration` WRITE;
/*!40000 ALTER TABLE `registration` DISABLE KEYS */;
INSERT INTO `registration` (`id`, `user_name`, `subject`, `user_email`, `content`, `baddress`, `modified_date`, `modified_time`) VALUES (17,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:07:59','2020-05-28 09:07:59'),(16,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 08:21:52','2020-05-28 08:21:52'),(15,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 08:02:10','2020-05-28 08:02:10'),(14,'admin','9811956594','110041','Plot no 555','4990- 3 Mega Large +  OIL (3 Month Course)','2020-05-26 17:07:30','2020-05-26 17:07:30'),(13,'ww','2323232323','','','3690- 2 Hammer of Thor +  OIL  (2 Month Course)','2020-05-26 15:29:52','2020-05-26 15:29:52'),(11,'dd','1212121212','125035','','','2020-05-26 15:24:46','2020-05-26 15:24:46'),(12,'dd','1212121212','125035','','','2020-05-26 15:25:52','2020-05-26 15:25:52'),(18,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:09:24','2020-05-28 09:09:24'),(19,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:10:29','2020-05-28 09:10:29'),(20,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:11:32','2020-05-28 09:11:32'),(21,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:19:20','2020-05-28 09:19:20'),(22,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:19:27','2020-05-28 09:19:27'),(23,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:20:17','2020-05-28 09:20:17'),(24,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:31:55','2020-05-28 09:31:55'),(25,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:37:40','2020-05-28 09:37:40'),(26,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:38:33','2020-05-28 09:38:33'),(27,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:44:09','2020-05-28 09:44:09'),(28,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:46:09','2020-05-28 09:46:09'),(29,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:50:02','2020-05-28 09:50:02'),(30,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:50:25','2020-05-28 09:50:25'),(31,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:50:46','2020-05-28 09:50:46'),(32,'अ','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:51:09','2020-05-28 09:51:09'),(33,'अ','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:51:09','2020-05-28 09:51:09'),(34,'अ','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:51:09','2020-05-28 09:51:09'),(35,'अ','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:51:09','2020-05-28 09:51:09'),(36,'अ','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:51:10','2020-05-28 09:51:10'),(37,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 09:56:00','2020-05-28 09:56:00'),(38,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:00:28','2020-05-28 10:00:28'),(39,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:00:33','2020-05-28 10:00:33'),(40,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:03:08','2020-05-28 10:03:08'),(41,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:09:57','2020-05-28 10:09:57'),(42,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:14:50','2020-05-28 10:14:50'),(43,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:16:20','2020-05-28 10:16:20'),(44,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:16:38','2020-05-28 10:16:38'),(45,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:16:52','2020-05-28 10:16:52'),(46,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:17:51','2020-05-28 10:17:51'),(47,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:18:26','2020-05-28 10:18:26'),(48,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:18:31','2020-05-28 10:18:31'),(49,'','','','','','2020-05-28 10:18:43','2020-05-28 10:18:43'),(50,' ऑअःकॅऑ','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:19:00','2020-05-28 10:19:00'),(51,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:21:25','2020-05-28 10:21:25'),(52,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:23:49','2020-05-28 10:23:49'),(53,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:25:03','2020-05-28 10:25:03'),(54,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:25:25','2020-05-28 10:25:25'),(55,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:27:26','2020-05-28 10:27:26'),(56,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:27:40','2020-05-28 10:27:40'),(57,'','','','','','2020-05-28 10:28:28','2020-05-28 10:28:28'),(58,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:31:07','2020-05-28 10:31:07'),(59,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:32:59','2020-05-28 10:32:59'),(60,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:34:15','2020-05-28 10:34:15'),(61,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:41:01','2020-05-28 10:41:01'),(62,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 10:51:57','2020-05-28 10:51:57'),(63,'aryan','8888888888','aryanbd@gmail.com','99','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 15:41:23','2020-05-28 15:41:23'),(64,'aryan','7777777777','aryanbd@gmail.com','77','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 15:41:32','2020-05-28 15:41:32'),(65,'ankit','9811956594','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-28 17:43:30','2020-05-28 17:43:30'),(66,'Sanjay kumar','9631710863','','Madhuban Chuk','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 03:40:06','2020-05-29 03:40:06'),(67,'ronak','9510674784','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 03:58:06','2020-05-29 03:58:06'),(68,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 04:44:51','2020-05-29 04:44:51'),(69,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 04:58:34','2020-05-29 04:58:34'),(70,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 04:58:51','2020-05-29 04:58:51'),(71,'','9999999999','ankit@gmail.com','22','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 05:53:12','2020-05-29 05:53:12'),(72,'Sagar raj','6205321245','','Gaya ...dobhi','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 06:20:37','2020-05-29 06:20:37'),(73,'Abhishek yadav','9174350353','ay830731@gmail.com','ओरछा','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 06:30:36','2020-05-29 06:30:36'),(74,'अभिषेक यादव','9174350353','ay830731@gmail.com','ओरछा','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 06:31:10','2020-05-29 06:31:10'),(75,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 06:32:10','2020-05-29 06:32:10'),(76,'','','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 06:32:19','2020-05-29 06:32:19'),(77,'SUNIL.MANKAR.','9881959574','','WANADONGRI','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 06:33:40','2020-05-29 06:33:40'),(78,'Devilal','9875765399','',' डूंगरिया वास','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 06:54:50','2020-05-29 06:54:50'),(79,'aryan','9999999999','aryanbd@gmail.com','55','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 07:49:39','2020-05-29 07:49:39'),(80,'aryan','9999999999','ankit@gmail.com','55','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 07:51:25','2020-05-29 07:51:25'),(81,'gaurav','1111111111','aryanbd@gmail.com','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 07:53:49','2020-05-29 07:53:49'),(82,'','','ankit@gmail.com','ff','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 07:54:22','2020-05-29 07:54:22'),(83,'aryan','9999999999','ankit@gmail.com','55','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 08:06:03','2020-05-29 08:06:03'),(84,'aryan','9815240888','ary@gmail.com','s2 multan','3690- 2 Mega Large +  OIL  (2 Month Course)','2020-05-29 08:06:39','2020-05-29 08:06:39'),(85,'gaurav','9815240888','s@gmail.com','66','4990- 3 Mega Large +  OIL (3 Month Course)','2020-05-29 08:08:10','2020-05-29 08:08:10'),(86,'gaurav1','2222223332','ankit@gmail.com','22','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 08:13:30','2020-05-29 08:13:30'),(87,'Raman','7061949120','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 09:42:18','2020-05-29 09:42:18'),(88,'aryan','2222555555','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 16:47:49','2020-05-29 16:47:49'),(89,'admin','9811956594','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-29 16:48:05','2020-05-29 16:48:05'),(90,'gaurav','2222111111','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-30 13:56:03','2020-05-30 13:56:03'),(91,'admin','9999999999','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-31 01:58:51','2020-05-31 01:58:51'),(92,'aryan','2020202020','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-31 01:59:07','2020-05-31 01:59:07'),(93,'admin','9999999999','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-31 01:59:23','2020-05-31 01:59:23'),(94,'aryan','7777777777','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-31 08:54:07','2020-05-31 08:54:07'),(95,'gaurav','7777777777','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-05-31 08:54:42','2020-05-31 08:54:42'),(96,'admin','1234567890','','','2290- 1 Mega Large +  OIL  (1 Month Course)','2020-06-11 14:09:55','2020-06-11 14:09:55');
/*!40000 ALTER TABLE `registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'buytiv3z_megalargecoin'
--

--
-- Dumping routines for database 'buytiv3z_megalargecoin'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-16  5:49:55
