<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kama-Sutra Gold | Penis Enlargment Pills </title>
    <!-- Bootstrap -->
    <link href="Content/css/bootstrap.css" rel="stylesheet">
    <link href="Content/css/style.css" rel="stylesheet">
    <link href="Content/css/custom.css" rel="stylesheet">
    <link href="Content/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="Content/css/Validation.css" rel="stylesheet" />

    <script src="Scripts/jquery-1.11.2.min.js"></script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="Scripts/bootstrap.js"></script>
    <script src="Scripts/Validation.js"></script>
    <script src="Scripts/custom.js"></script>


    <!-- <link rel="stylesheet" href="font-awesome.min.css"> -->

    <!-- <style>
    *{
        margin: 0;
        padding: 0;
    }
</style> -->



</head>

<body>


    <header class="header">
        <div class="container-fluid">
            <div class="row ">

                <div class="col-sm-3 col-xs-12 text-center pull-left text-white noPadding topcontent" style="">
                    <h2>100% Ayurvedic</h2>
                    <h2> Capsules </h2>
                </div>
                <!--<div class="col-sm-4 col-xs-12 col-sm-offset-1 text-center"><h1  class="text-gold"><b>Kama-Sutra Gold</b></h1></div>-->
                <div class="col-sm-6 col-xs-12 text-center noPadding"><img src="Content/images/new/KS-GOLD1.png" id="logo"></div>

                <div class="col-sm-3 col-xs-12 text-center pull-right text-white noPadding">
                    <div class="toplogo text-center">
                        <h3 class="text-left" id="gupt" style="margin-bottom: 5px; ">आपकी जानकारी गुप्त रखी जाएगी</h3>
                        <div align="center" class="col-sm-3 col-xs-4 noPadding"><img src="assets/guranteed-logo.png" class="img-responsive" alt=""></div>

                        <div align="center" class="col-sm-3 col-xs-4  noPadding"><img src="assets/gmp-logo.png" class="img-responsive" alt=""></div>

                        <div align="center" class="col-sm-3 col-xs-4 noPadding"><img src="assets/natural.png" class="img-responsive" alt=""></div>
                    </div>
                </div>

            </div>

        </div>
        <!-------container-------------->
    </header>

    <div class="container-fluid ">
        <div class="form absolute noPadding" id="bookform">
            <div class="header strip3 text-center visible-xs" style="background:#4169E1; background-color: #dcb339; padding: 5px; text-align: center;">
                <h3><strong>PENIS ENLARGEMENT:UP-TO 5 INCHES!</strong></h3>
                <h3><strong><b>लिंग में वृद्धि: 5 इंच तक!</b></strong></h3>



            </div>

            <div class="header strip3 text-center  visible-xs" style="background:#00008B; background-color: #b77e1d; padding: 5px; text-align: center;">
                <h3><strong><b>Enhance Sex Timing By More Than 60 Minutes</b></strong></h3>
                <h3><strong><b>सेक्स का समय 1 घंटे से ज़्यादा बढ़ाएं </b></strong> </h3>



            </div>
            <div class="header strip3 text-center hidden-xs" style="background-color: #000;">
                <h3><a style="font-size: 32px;"><strong><b>BOOK ORDER NOW!<br><br> Discount Offer</b></strong></a>
                </h3>
                <h1 class="text-center"><a style="font-size: 32px;" id="ordernumber"><i class="fa fa-phone"></i> 50% OFF
                    </a></h1>


            </div>
            <div class="header strip3 text-center hidden-xs" style="background:#4169E1; background-color: #dcb339; padding: 5px; text-align: center;">
                <h3><strong><b>PENIS ENLARGEMENT : UP</b></strong></h3>
                <h3><strong><b>TO 5 INCHES!</b></strong></h3>
                <h3><strong><b>लिंग में वृद्धि: 5 इंच तक!</b></strong></h3>



            </div>

            <div class="header strip3 text-center  hidden-xs" style="background:#00008B; background-color: #b77e1d; padding: 5px; text-align: center;">
                <h3><strong>Enhance Sex Timing By More Than 60 Minutes</strong></h3>
                <h3><strong><b>सेक्स का समय 1 घंटे से ज़्यादा बढ़ाएं </b></strong> </h3>



            </div>
            <form id="enquiryform" enctype="multipart/form-data" method="post" class="form-groups-bordered form-horizontal" action="">
                <br>
                <div class="form-group">
                    <label class="control-label col-sm-3">आपका नाम </label>
                    <div class="col-sm-9">
                        <input class="form-control" rquired placeholder="आपका नाम" value="" name="userName">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-3">आपका फोन</label>
                    <div class="col-sm-9">
                        <input class="form-control" required placeholder="आपका फोन" value="" name="subject" id="mobile" type="text">
                        <span id="mobileerror"></span>
                    </div>
                </div>

                <!-- <div class="form-group">
                    <label class="control-label col-sm-3">Address</label>
                    <div class="col-sm-9">
                        <textarea class="form-control" required name="address" placeholder="Address"></textarea>
                    </div>
                </div> -->


                <div class="form-group">
                    <label class="control-label col-sm-3">कोर्स</label>
                    <div class="col-sm-9">


                        <select class="form-control" type="text" value="" required name="baddress">
                            <option selected="selected" value="Pack of 30 कैप्सूल"> Pack of 30 कैप्सूल</option>
                            <option value="Pack of 60 कैप्सूल"> Pack of 60 कैप्सूल</option>
                            <option value="Pack of 90 कैप्सूल"> Pack of 90 कैप्सूल</option>
                        </select>
                        <span id="packageerror"></span>
                    </div>
                </div>

                <center><button type="submit" value=" अभी ऑर्डर करें " name="send" onclick="submit_form()" class="btn btn-danger btn-lg">SUBMIT</button></center>
            </form>
            <div class="clearfix"></div>
            <hr>
            <?php
            if (!empty($message)) {
            ?>
                <p class='<?php echo $type; ?>Message'>
                    <?php
                    echo '<script language="javascript">';
                    echo 'window.location = "db.php";';
                    echo '</script>';
                    ?>
                </p>
            <?php
            }
            ?>

        </div>


    </div>


    <section class="section1">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-8 noPadding" id="topcontent">
                    <div class="col-sm-3 noPadding"><img id="banner-image" src="Content/images/new/banner-image.png">
                    </div>
                    <div class="col-sm-9 noPadding">
                        <div class="col-sm-12">
                            <h2 class="blink_me" id="firsttime"><span class="col-sm-6 col-xs-12 noPadding text-left">First Time In India!!</span><span class="col-sm-6 col-xs-12 noPadding text-right"> भारत में पहली बार!!</span></h2>
                            <h2 class="col-sm-12 col-xs-12 text-center redyellow" style="font-size: 41px;"><b>Kama-Sutra
                                    Gold </b></h2>

                            <h3 class="col-sm-12 col-xs-12 text-center whiteblue" style="font-size: 28px;">अपने लिंग पे
                                2 बार लगाये और सेक्स करे लगातार </h3><br>
                            <h2 id="guarantee" class="col-sm-12 col-xs-12 ">
                                <span style="font-size: 22px;" class="col-sm-6 col-xs-12 text-right noPadding">100% मनी
                                    बैक गारंटी</span>
                            </h2>
                        </div>

                        <div class="clearfix"></div>
                        <div class="col-sm-12 noPadding">
                            <div class="col-sm-7 noPadding text-center">
                                <center>
                                    <a href="#enquiryform"><img id="imglogo" src="Content/images/new/product.png" class="img img-responsive">
                                    </a>
                                </center>
                            </div>

                            <div class="col-sm-5 noPadding">



                                <style type="text/css">
                                    .strip1 h2 {
                                        font-size: 27px;
                                        padding-bottom: 1px;
                                    }
                                </style>

                                <div class="text text-center">
                                    <div class="strip1">
                                        <!-- <h2>Enlarge Penis Size & Thickness</h2> -->
                                        <h2 style="color:#FFFFFF">लिंग की लम्बाई और मोटाई बढ़ाएं</h2>
                                    </div>
                                    <div class="strip1 ">
                                        <!-- <h2>Boost your Stamina & Time</h2> -->
                                        <h2 style="color:#FFFFFF">संभोग की शक्ति एवं समय बढ़ाएं</h2>

                                    </div>
                                    <div class="strip1">
                                        <!-- <h2>Feel Satisfaction & Pleasure</h2> -->
                                        <h2 style="color:#FFFFFF">पूर्ण संतुष्टि और आनन्द महसूस करें</h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-2"></div>

                </div>
            </div>
    </section>

    <!--<div class="blink_me">BLINK ME</div>-->
    <section class="section4">

        <!---------------Reality Portion Ends-------------------------->

        <div class="container">

            <div class="reality-section1">

                <div class="reality-section-border"></div>

                <div align="center">

                    <h1 id="ordernow" class="text-danger text-center" style=""><br> अभी ऑर्डर करे! आपको हमारे एक्सपर्ट
                        डॉक्टर से कॉल बैक होगा</h1>
                    <!-- 
                    <h1 class="style5">अभी ऑर्डर करे! आपको हमारे आयुर्वेदिक डॉक्टर से कॉल बैक होगा</h1> -->

                    <hr>

                    <div class="reality-section">

                        <h1 class="text-center blink_me " style="color: #DAA520;">THE PROBLEM</h1>



                        <div class="reality-section-bar"><img src="assets/reality/reality-blue-bar.png" class="img-responsive" alt=""></div>

                        <div class="reality-section-thumbs">

                            <div class="row">

                                <div align="center" class="col-sm-3">

                                    <a href="#enquiryform"><img src="assets/reality/reality-pic1.jpg" class="img-responsive" alt=""></a>



                                </div>

                                <div align="center" class="col-sm-3">

                                    <a href="#enquiryform"> <img src="assets/reality/reality-pic2.jpg" class="img-responsive" alt="">
                                    </a>


                                </div>

                                <div align="center" class="col-sm-3">

                                    <a href="#enquiryform"> <img src="assets/reality/reality-pic3.jpg" class="img-responsive" alt="">

                                    </a>

                                </div>

                                <div align="center" class="col-sm-3">

                                    <a href="#enquiryform"> <img src="assets/reality/reality-pic4.jpg" class="img-responsive" alt="">

                                    </a>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="reality-section">

                        <h1 class="text-center blink_me" style="color: #00a65a;">THE SOLUTION</h1>

                        <h3 style="font-weight: 800; padding-bottom: 10px; " class="text-center bold">DO NOT WORRY!
                            KAMA-SUTRA GOLD WILL SOLVE ALL YOUR SEXUAL PROBLEMS!</h3>

                        <h3 class="text-center" style="font-weight: 800; padding-bottom: 10px; "> चिंता मत करो!
                            KAMA-SUTRA GOLD आपके सभी यौन समस्याओं को हल करेगा!</h3>

                        <div class="reality-section-bar">
                            <img src="assets/reality/reality-blue-bar.png" class="img-responsive" alt="">
                        </div>

                        <div class="reality-section-thumbs">

                            <div class="row">

                                <div align="center" class="col-sm-4">

                                    <a href="#enquiryform"> <img src="assets/reality/solution-img-1.jpg" class="img-responsive" alt=""></a>



                                </div>

                                <div align="left" class="col-sm-4">

                                    <ul class="style8">

                                        <li> 5 इंच तक लिंग का आकार बढ़ाएं</li>

                                        <hr style="margin-top:5px; margin-bottom:: 5px;">

                                        <li> यौन समय में 45 मिनट तक महत्वपूर्ण वृद्धि</li>

                                        <hr style="margin-top:5px; margin-bottom:: 5px;">

                                        <li>अत्यंत कठोर खड़ापन</li>

                                        <hr style="margin-top:5px; margin-bottom:: 5px;">

                                        <li>पाएँ लंबे समय तक खड़ापन</li>

                                        <hr style="margin-top:5px; margin-bottom:: 5px;">

                                        <li>अपने साथी को अंतिम संतुष्टि प्रदान करें</li>

                                    </ul>

                                </div>

                                <div align="center" class="col-sm-4">

                                    <a href="#enquiryform"> <img src="Content/images/new/5.jpg" class="img-responsive" alt="">
                                    </a>


                                </div>



                            </div>

                        </div>





                    </div>





                </div>

                <div class="reality-section-bar"><img src="assets/reality/reality-blue-bar.png" class="img-responsive" alt=""></div>



            </div>

            <!---------------Reality Portion Ends-------------------------->

    </section>
    <style>
        .reality-section {
            padding: 0px 0px 70px 0px;
        }

        .reality-section-border {
            /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#ffffff+0,d2d2d2+17,f0f0f0+34,f0f0f0+34,e2e2e2+50,f9f9f9+64,d2d2d2+79,ffffff+100 */
            background: #f5f5f5;
            /* Old browsers */
            background: -moz-linear-gradient(left, #ffffff 0%, #d2d2d2 17%, #f0f0f0 34%, #f0f0f0 34%, #e2e2e2 50%, #f9f9f9 64%, #d2d2d2 79%, #ffffff 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(left, #ffffff 0%, #d2d2d2 17%, #f0f0f0 34%, #f0f0f0 34%, #e2e2e2 50%, #f9f9f9 64%, #d2d2d2 79%, #ffffff 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(to right, #ffffff 0%, #d2d2d2 17%, #f0f0f0 34%, #f0f0f0 34%, #e2e2e2 50%, #f9f9f9 64%, #d2d2d2 79%, #ffffff 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid: DXImageTransform.Microsoft.gradient(startColorstr='#f5f5f5', endColorstr='#f5f5f5', GradientType=1);
            /* IE6-9 */
            ;
            height: 08px;
            margin-top: 2px;
        }

        .reality-section-thumbs img {
            padding-bottom: 10px;
        }

        .reality-section-bar {
            padding-bottom: 20px;
        }

        .reality-section-thumbs {}
    </style>

    <section class="section6" id="benefits">


        <!---------------How Portion Starts-------------------------->
        <style>
            /*-------------------How Section Starts------------------*/

            .section6 {}

            .reality-section-border {
                /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#ffffff+0,d2d2d2+17,f0f0f0+34,f0f0f0+34,e2e2e2+50,f9f9f9+64,d2d2d2+79,ffffff+100 */
                background: #f5f5f5;
                /* Old browsers */
                background: -moz-linear-gradient(left, #ffffff 0%, #d2d2d2 17%, #f0f0f0 34%, #f0f0f0 34%, #e2e2e2 50%, #f9f9f9 64%, #d2d2d2 79%, #ffffff 100%);
                /* FF3.6-15 */
                background: -webkit-linear-gradient(left, #ffffff 0%, #d2d2d2 17%, #f0f0f0 34%, #f0f0f0 34%, #e2e2e2 50%, #f9f9f9 64%, #d2d2d2 79%, #ffffff 100%);
                /* Chrome10-25,Safari5.1-6 */
                background: linear-gradient(to right, #ffffff 0%, #d2d2d2 17%, #f0f0f0 34%, #f0f0f0 34%, #e2e2e2 50%, #f9f9f9 64%, #d2d2d2 79%, #ffffff 100%);
                /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
                filter: progid: DXImageTransform.Microsoft.gradient(startColorstr='#f5f5f5', endColorstr='#f5f5f5', GradientType=1);
                /* IE6-9 */
                ;
                height: 08px;
                margin-top: 2px;
            }

            .reality-section-bar {
                padding-bottom: 20px;
            }

            .how-section {
                background: url() no-repeat center top;
                margin-bottom: 07px;
            }

            .how-section-img {
                float: right;
                padding-top: 30px;
            }

            .how-section-left-padding {
                padding-top: 62px;
            }

            ul.list3 {
                padding: 30px 10px 0px 10px;
                list-style: none;
                font-family: 'Lato', sans-serif;
                font-size: 17px;
                font-style: italic;
                color: #ffffff !important;
                /* text-shadow: 0px 1px 2px #f1e8da; */
            }

            @media (max-width: 768px) {
                ul.list3 {
                    padding: 10px 10px 0px 10px;
                    list-style: none;
                    font-family: 'Lato', sans-serif;
                    font-size: 17px;
                    font-style: italic;
                    /* text-shadow: 0px 1px 2px #f1e8da; */
                }

                /*-------------------Reality Section Ends------------------*/
                .reality-section {
                    padding: 0px 0px 30px 0px;
                }

                .reality-section h4 {
                    width: 100%;
                }

                .reality-section-thumbs img {
                    padding-bottom: 10px;
                }

                /*-------------------Reality Section Ends------------------*/
                /*-------------------How Section Starts------------------*/
                .how-section {
                    height: auto;
                    background: none;
                    margin-bottom: 20px;
                }

                .how-section h1 {
                    font-size: 44px;
                }

                .how-section h2 {
                    font-size: 48px;
                }

                .how-section-img {
                    float: right;
                    padding-top: 20px;
                }

                .how-section-left-padding {
                    padding-top: 20px;
                }

                .how-section h3 {
                    font-size: 18px;
                    color: #ffffff;
                    font-weight: bold;
                    line-height: 24px;
                }

                .how-section-hindi {
                    line-height: 50px;
                    font-size: 40px;
                }

                ul.list3 {
                    padding: 10px 10px 0px 10px;
                    list-style: none;
                    font-family: 'Lato', sans-serif;
                    font-size: 17px;
                    font-style: italic;
                    /* text-shadow: 0px 1px 2px #f1e8da; */
                }

                .list3 li:before {
                    content: url();
                    font-family: 'FontAwesome';
                    padding: 0px 12px 0px 0px;
                    font-weight: normal;
                    position: relative;
                    top: 10px;
                }

                .how-section h5 {
                    font-size: 58px;
                    color: #ffffff;
                    font-weight: 900;
                    padding-bottom: 15px;
                    text-transform: uppercase;
                }

                .apply-cream {
                    padding-top: 0px;
                }

                /*-------------------How Section Ends------------------*/
            }

            .list3 li:before {
                content: url();
                font-family: 'FontAwesome';
                padding: 0px 12px 0px 0px;
                font-weight: normal;
                position: relative;
                top: 10px;
            }

            .how-section h4 {
                font-size: 22px;
                font-family: 'Lato', sans-serif;
                color: #123879;
                font-style: italic;
                font-weight: bold;
                line-height: 29px;
                padding-bottom: 10px;
            }

            .how-section-hindi {
                font-size: 32px;
                font-family: 'Lato', sans-serif;
                color: #123879;
                font-style: italic;
                font-weight: bold;
                line-height: 29px;
                padding-bottom: 10px;
            }

            .apply-cream {
                padding-top: 63px;
            }

            /*-------------------How Section Ends------------------*/
        </style>
        <div class="how-section">

            <div class="container">

                <!-- <h1 class="redyellow" align="center" style="font-size: 45px;">HOW KAMA-SUTRA GOLD WORKS?</h1> -->
                <h1 class="redyellow" align="center" style="font-size: 45px;">Kama-Sutra Gold कैसे काम करता है ?</h1>
                <br>

                <h5 class="redyellow" align="center">पूर्ण करें योन कार्यक्षमता</h5>

                <div class="row">

                    <div class="col-sm-6">

                        <div class="how-section-left-padding">

                            <h3>पुरुषों के लिए बढ़िया इस औषधि का उपयोग करके लिंग के आकार में 5 इंच वृद्धि का लाभ उठाएं
                            </h3>

                            <ul class="list3">
                                <li>KAMA-SUTRA GOLD कैप्सूल की 1 बोतल, 0.5 इंच या उससे अधिक के लिंग वृद्धि का उत्पादन
                                    करेगा</li>

                                <br>
                                <li>KAMA-SUTRA GOLD कैप्सूल की 2 बोतलें 2 इंच या उससे अधिक के लिंग वृद्धि का उत्पादन
                                    करेगा</li>

                                <br>

                                <li>KAMA-SUTRA GOLD कैप्सूल की 3 बोतलें 5 इंच या उससे अधिक के लिंग वृद्धि का उत्पादन
                                    करेगा</li>

                            </ul>





                            <br>


                            <div class="how-section-hindi">सभी आर्डर पर 100% संतुष्टि की गारंटी है।</div>

                        </div>

                    </div>

                    <div class="col-sm-6 no-padding">

                        <div class="apply-cream">
                            <a href="#bookform"> <img src="assets/reality/practice.jpg" style="width:100%">
                            </a>
                        </div>

                        <p align="center"> Please contact Customer Care in detail before use.</p>
                        <div class="how-section-img"></div>

                    </div>

                </div>
            </div>
        </div>
    </section>

    <!--------------------------------HOW KAMA-SUTRA GOLD -->


    <section class="section6" align="center" id="about">

        <!---------------Ingredients Portion-Responsive Starts-------------------------->


        <!---------------Ingredients Portion-Responsive Ends-------------------------->

        <div class="clearfix"></div>

        <div class="container">

            <div class="reality-section1">

                <div class="reality-section-border"></div>

                <div align="center">



                    <hr>

                    <div class="reality-section">

                        <h1 class="redyellow">INGREDIENTS USED FOR PILLS</h1>

                        <style>
                            #products {
                                background-image: url(Content/images/backgrounds/bg5.jpg);
                                background-size: cover;
                                background-repeat: no-repeat;
                            }

                            .bg-b {
                                background-image: url(Content/images/backgrounds/bg4.jpg);
                                background-size: cover;
                                background-repeat: no-repeat;
                            }

                            .bg-c {
                                background-image: url(Content/images/backgrounds/bg-5.jpg);
                                background-size: cover;
                                background-repeat: no-repeat;
                            }
                        </style>
                        <div id="products">
                            <a href="#bookform"> <img src="Content/images/new/BOTTLE-KS.png" class="img-responsive" alt="" width="200"></a>
                        </div>
                        <div class="reality-section-bar"><img src="assets/reality-blue-bar.png" class="img-responsive" alt=""></div>

                        <div class="reality-section-thumbs">

                            <div class="row">

                                <div class="col-sm-3 noPadding">
                                    <div class="img">
                                        <img src="assets/2.jpg" class="img-responsive" alt="">
                                    </div>
                                    <h4>Black Asphaltum </h4>
                                    <p class="text-left">
                                        इसमें शक्तिशाली एंटीऑक्सिडेंट और खनिज होते हैं, जो पुरुष जननांगों में उचित रक्त
                                        प्रवाह सुनिश्चित करते हैं। यह पूरक बेहतर यौन उत्तेजना के लिए चिंता और तनाव से भी
                                        छुटकारा दिला सकता है और किसी की शक्ति को बढ़ाता है। यह आपको पुरानी थकान से लड़ने
                                        और ऊर्जा
                                        को बढ़ावा देने में मदद कर सकता है।

                                    </p>

                                </div>


                                <div class="col-sm-3 noPadding">
                                    <div class="img">


                                        <img src="assets/oil-ing3.jpg" class="img-responsive" alt="">
                                    </div>
                                    <h4> <strong>Withania somnifera</strong></h4>
                                    <p class="text-left">
                                        कामोत्तेजक होने के कारण, अश्वगंधा आपकी यौन इच्छा को बढ़ा सकता है। यह नाइट्रिक
                                        ऑक्साइड के उत्पादन को उत्तेजित करके और जननांगों में रक्त के प्रवाह को बढ़ाकर काम
                                        करता है। अश्वगंधा का सेवन वास्तव में आपके रक्त को बेहतर परिसंचरण में मदद करता
                                        है।</p>
                                    </p>
                                </div>
                                <div class="col-sm-3 noPadding">
                                    <div class="img">

                                        <img src="assets/1.jpg" class="img-responsive" alt="">
                                    </div>


                                    <h4>Tribulus terrestris</h4>

                                    <p class="text-left">
                                        कम सेक्स ड्राइव के साथ महिलाओं और पुरुषों में कामेच्छा में सुधार। जड़ी बूटी के
                                        रूप में अध्ययन स्तंभन दोष के लिए एक उपचार ने उच्च के साथ मिश्रित परिणाम दिखाए
                                        हैं खुराक अधिक लाभकारी प्रतीत होती है।

                                </div>
                                <div class="col-sm-3 noPadding">
                                    <div class="img">
                                        <img src="assets/cream-ing1.jpg" class="img-responsive" alt="">
                                    </div>



                                    <h4> Chlorophytum Tuverosuw</h4>
                                    <p class="text-left">
                                        सफ़ेद मुसली भारत की एक दुर्लभ जड़ी बूटी है। इसका उपयोग आयुर्वेद, यूनानी और
                                        होम्योपैथी सहित चिकित्सा की पारंपरिक प्रणालियों में किया जाता है। यह पारंपरिक
                                        रूप से गठिया, कैंसर, मधुमेह, जीवन शक्ति बढ़ाने, यौन प्रदर्शन में सुधार और कई
                                        अन्य उपयोगों के लिए उपयोग
                                        किया जाता है।


                                    </p>
                                </div>
                            </div>

                        </div>

                    </div>



                    <div class="clearfix"></div>

                </div>
            </div>
        </div>

    </section>



    <section class="section7">
        <!---------------Testimonial Portion Ends-------------------------->

        <div class="container">

            <div class="testimonial-section">

                <h1 align="center">SATISFACTION ACHIEVED BY</h1>

                <h2 align="center">OUR CUSTOMERS IS PHENOMENAL</h2>

                <h3 align="center">They have added spice to their sex lives with these energy pills.</h3>

                <div class="row">

                    <div class="col-sm-6">
                        <a href="#bookform"><img src="assets/FEEDBACK.jpg" class="img-responsive" alt="">
                        </a>
                    </div>

                    <div class="col-md-6 col-sm-12">


                        <h4>KAMA-SUTRA GOLD वास्तव में कितना अच्छा काम काम करता है?</h4>




                        <div class="carousel slide padding-top" data-ride="carousel" data-interval="3000">

                            <!-- Carousel indicators -->

                            <ol class="carousel-indicators">

                                <li data-target="#fade-quote-carousel" data-slide-to="0" class=""></li>

                                <li data-target="#fade-quote-carousel" data-slide-to="1" class="active"></li>

                                <li data-target="#fade-quote-carousel" data-slide-to="2" class=""></li>

                                <!--<li data-target="#fade-quote-carousel" data-slide-to="3"></li>

                            <li data-target="#fade-quote-carousel" data-slide-to="4"></li>

                            <li data-target="#fade-quote-carousel" data-slide-to="5"></li>-->

                            </ol>

                            <!-- Carousel items -->

                            <div class="carousel-inner">

                                <div class="item">

                                    <div><img src="assets/1234.png" class="img-responsive" alt=""></div>

                                    <blockquote>

                                        <p>

                                            <font size="3" color="#FF0000">Vivek from Kanpur</font><br>

                                            <big>“</big>कृतज्ञता व्यक्त करने के लिए मेरे पास शब्द नहीं हैं KAMA-SUTRA
                                            GOLD ने वास्तव में मेरे रिश्ते को बचाया है मैं बिस्तर में 2-3 मिनट से अधिक
                                            समय तक रोक नहीं पा रहा था और मेरी पत्नी बहुत परेशान थी। मैंने
                                            अपना आत्मविश्वास खो दिया था तो मुझे एक वेबसाइट से इस उत्पाद के बारे में पता
                                            चल गया। मैंने आर्डर दे दिया और निर्धारित समय में प्राप्त भी हो गया । मैंने
                                            इसे निर्देशानुसार लेना शुरू कर दिया और हर गुजरते दिन के
                                            साथ मेरे यौन जीवन में सुधार हुआ। मेरी रहने की शक्ति अस्थिर हो गई और लिंग का
                                            आकार भी बढ़ गया। मेरी पत्नी अब मेरे साथ बहुत खुश हैं क्योंकि मैं रात भर उसको
                                            अधिकतम खुशी प्रदान कर सकता हूं। धन्यवाद!”
                                        </p>

                                    </blockquote>

                                </div>

                                <div class="item active">

                                    <div class="profile-circle"><img src="assets/1234.png" class="img-responsive" alt=""></div>

                                    <blockquote>

                                        <p>

                                            <font size="3" color="#FF0000">Rishab Arora from Gurgaon</font><br>

                                            <big>“</big>यह Kama-Sutra Gold कितना अद्भुत पूरक है! जब मैंने अपने एक दोस्त
                                            को अपनी सेक्स लाइफ की समस्याओं के बारे में बताया तो उसने मुझे यह उत्पाद
                                            सुझाया। मुझे संदेह था फिर भी मैंने इसे आदेश दिया क्योंकि मैं था
                                            बिस्तर में बेहतर प्रदर्शन करने और अपनी प्रेमिका को संतुष्ट करने के लिए
                                            बेताब। परिणाम अविश्वसनीय थे। उपयोग के 4 सप्ताह के भीतर, मुझे आश्चर्यजनक
                                            परिवर्तन महसूस हुए। मुझे स्थिर और मजबूत इरेक्शन होने के साथ-साथ सुधार भी
                                            होने लगा
                                            मेरी सहनशक्ति बहुत। अब, मैं लगातार 1 घंटे तक सेक्स ड्राइव का आनंद ले सकता
                                            हूं और मेरी प्रेमिका मुझसे खुश है।
                                        </p>

                                    </blockquote>

                                </div>

                                <div class="item">

                                    <div class="profile-circle"><img src="assets/1234.png" class="img-responsive" alt=""></div>

                                    <blockquote>

                                        <p>

                                            <font size="3" color="#FF0000">Sumit Kumar from Gujarat</font><br>

                                            <big>“</big>मेरे रिश्ते में खुशी को वापस लाने के लिए KAMA-SUTRA GOLD और इसके
                                            निर्माता को बहुत बहुत धन्यवाद| यह मेरे यौन जीवन में एक जीवन-परिवर्तन तत्व
                                            साबित हुआ है जो इस औषधि से पहले बहुत ही उबाऊ और निराशाजनक
                                            थी । इस पुरुष वृद्धि पूरक के पाठ्यक्रम को पूरा करने के बाद इसने मेरे लिंग को
                                            5 इंच से 7.1 इंच तक बढ़ा दिया गया है और अधिक शक्तिशाली बना दिया है । अब न
                                            केवल मैं अपने साथी की हर इच्छा को पूरा करता हूं, बल्कि हम
                                            दोनों पहले से कहीं ज्यादा आवेशपूर्ण और गहन सेक्स का आनंद उठाते हैं।
                                        </p>

                                    </blockquote>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <!---------------Testimonial Portion Ends-------------------------->

        <!---------------Real Result Portion Starts-------------------------->

        <div class="container">

            <div class="result-section">

                <h1 align="center">हमारे संतुष्ट ग्राहकों की स्पष्ट पुष्टि</h1>

                <h2 align="center">साथ की तस्वीरें और घोषणाएं हमारे समर्पित ग्राहकों द्वारा भेजी गई थीं:</h2>

                <div class="row">

                    <div class="col-sm-4">

                        <div><img src="assets/testi-pic1.png" class="img-responsive" alt=""></div>
                        <div class="result-section-text">

                            हमारी शादी के बाद मेरी पत्नी के पास बहुत शिकायते थी कारण मेरा छोटा लिंग और सेक्स के दौरान कम
                            ऊर्जा । मैंने कई प्रकार के उत्पादों का इस्तेमाल किया लेकिन वास्तव में कुछ भी काम नहीं किया।
                            बल्कि , उनमें से कुछ दुष्प्रभावों का कारण बने। फिर मुझे KAMA-SUTRA
                            GOLD के बारे में पता चला और इसे आर्डर किया । चूंकि मैंने इस उत्पाद का उपभोग करना शुरू कर
                            दिया है, इसलिए मुझे शानदार परिणाम मिल गए हैं। मेरे लिंग का आकार बढ़ा है और मेरे प्रदर्शन में
                            भी बढ़ोतरी हुई है। मेरी पत्नी अब शिकायत नहीं
                            करती है, वह सिर्फ मुझ पर बहुत प्यार दिखाती है शानदार उत्पाद </div>

                    </div>

                    <div class="col-sm-4">

                        <div><img src="assets/testi-pic2.png" class="img-responsive" alt=""></div>
                        <div class="result-section-text">

                            KAMA-SUTRA GOLD की सहायता से मैंने अपना खोया आत्मविश्वास पुनः प्राप्त कर लिया है I जीवन में
                            पहली बार, मैं एक असली आदमी की तरह लग रहा हूँ | सेक्स के दौरान घंटो तक चल रहा है भरपूर जोश और
                            ताक़त साथ वो भी बिना स्खलन के । मेरा लिंग अब अधिक मजबूत और कठोर है
                            और लंबे समय तक बने रह सकता है। आपका बहुत बहुत धन्यवाद! </div>

                    </div>

                    <div class="col-sm-4">

                        <div><img src="assets/testi-pic3.png" class="img-responsive" alt=""></div>

                        <div class="result-section-text">

                            KAMA-SUTRA GOLD ने मेरी सेक्स लाइफ पूरी तरह से बदल दी है, अब मैं अपनी गर्लफ्रेंड को, जो वह
                            खुशियाँ चाहती हैं और हकदार हैं प्रदान कर सकता हूं ! मेरे लंबे और बड़े लिंग और बेहतर जीवन
                            शक्ति के साथ, मैं उसे उत्तेजना और परमानंद की ऊंचाई पर ले जाता हूं। उसका
                            ज़ोर से चिल्लाना और मुहब्बत करना यह सबूत है कि वह मेरे साथ सेक्स का कितना आनंद लेती है
                        </div>

                    </div>

                </div>

            </div>

        </div>

        <!---------------Real Result Portion Ends-------------------------->
    </section>



    <section class="secret-section">


        <!---------------Secret Delivery Portion Starts-------------------------->

        <div class="secret-section">

            <div class="row">

                <div class="col-sm-1"></div>

                <div align="center" class="col-sm-3">

                    <div class="secret-section-order">

                        <a href="#bookform">Order Now</a>
                    </div>

                    <a href="#bookform"> <img src="assets/footer-icon.png" class="img-responsive" alt=""></a>
                </div>



                <div class="col-sm-4 no-padding">

                    <div class="secret-section-punch">

                        <h4>SECRET DELIVERY</h4>

                        <h5>ORDER ANY PACKAGE AND RECEIVE</h5>

                        <h6>प्रोडक्ट की गुप्त डिलीवरी </h6>

                        <!-- <h7>भारत भर में</h7> -->

                    </div>

                </div>

                <div class="col-sm-4">

                    <div class="secret-section-rightside">

                        <img src="assets/secret-delivery-pic.png" class="img-responsive" alt="">
                    </div>

                </div>

            </div>

        </div>



        <!---------------Secret Delivery Portion Starts-------------------------->

    </section>








    <footer class="footer">
        <div align="center" style="color: #fff;">

            <div class="footer-link"></div>

            <div align="center">

                <h2 class="redyellow"><b>KAMA-SUTRA GOLD</b></h2>

                <p style="color: #fff;">T&amp;C :- *If anyone comes to us through web or phone, He/She will liable to
                    get calls from our side.</p>
            </div>

            <h5>Copyright@ kama-sutra Gold All rights reserved </h5>
            <p>Disclaimer: "These statements have not been evaluated by the Food and Drug Administration. <br> This
                product is not intended to diagnose, treat, cure, or prevent any disease.</p>


        </div>
        <div class="text-center" id="bottomorder" style="display:none; background-color:rgba(0, 0, 0, 0.8); position: fixed; width: 100%; padding: 5px; z-index: 1; bottom: 0px;    font-size: 30px;    font-weight: 900; ">
            <a href="#bookform" class="whiteblue">Order Now</a>
        </div>
        <!-- <div class="text-center visible-xs"
            style="background-color:#000 !important; position: fixed; width: 100%; padding: 5px; z-index: 1; top: 0px;    font-size: 30px;    font-weight: 900;  ">
            <h3><a href="tel:0000000000" style="font-size: 32px; color: #fff; font-weight: 800;">अभी कॉल करें</a></h3>
            <h1 class="text-center"><a style=" color:red; font-size: 32px; font-weight: 900;" href="tel:7888690430"><i
                        class="fa fa-phone"></i> 0000000000</a></h1>


            </a>
        </div>-->

    </footer>

    <script type="text/javascript">
        var myVar = setInterval(setColor, 300);

        function setColor() {
            var x = document.getElementById('ordernumber');
            x.style.color = x.style.color == "red" ? "#ffcf20" : "red";
            $('.fa-phone').css('color', x.style.color);
        }
        $(window).scroll(function() {
            if ($(window).scrollTop() > 800) {
                // > 100px from top - show div
                $('#bottomorder').show();
            } else {
                // <= 100px from top - hide div
                $('#bottomorder').hide();
            }
        });
    </script>


</body>

</html>